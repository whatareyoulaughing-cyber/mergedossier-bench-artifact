# External Audit Slice Instructions

This packet contains a deterministic 10% external audit slice for the AIDev-pop handoff-evidence study.
It is designed for a second operator or external reviewer to independently code the same evidence-availability families.

- Tasks: 50
- Sampling seed: 20260617
- Source task file: `outputs/population_ai_pr_500_20260616/reports/annotation_tasks.json`

## Files

- `external_audit_tasks.json`: Label Studio import tasks.
- `external_audit_sheet.csv`: spreadsheet-friendly audit sheet with blank audit-code columns.
- `external_audit_sheet.xlsx`: Excel workbook with dropdowns, instructions, and completion checks when openpyxl is available.
- `external_audit_manifest.json`: selected instance IDs and packet metadata.

## Coding Boundary

Use the existing audit-code vocabulary: `present`, `partially_present`, `missing`, and `not_applicable`.
The task is to assess visible review-evidence availability, not patch correctness, mergeability, reviewer utility, or AI-vs-human effects.
If completed, these rows can support an external audit slice. Until completed, the main paper should continue to report single-operator self-consistency only.

## After Completion

Save the completed sheet as a CSV and run:

```bash
python scripts/check_external_audit_progress.py \
  --audit <completed_external_audit_sheet.xlsx-or-csv> \
  --out outputs/external_audit_progress_20260617

python scripts/check_external_audit_return.py \
  --completed <completed_external_audit_sheet.xlsx-or-csv> \
  --out outputs/external_audit_analysis_20260617
```

The progress helper accepts either a workbook or CSV and writes a completion
report plus `AUDITOR_FEEDBACK_REQUEST.md` if cells still need attention.
The return helper accepts either the completed workbook or a CSV export. It writes
`external_audit_return_status.md` and reruns the agreement analysis. Manual CSV
analysis is also available:

```bash
python scripts/analyze_external_audit_slice.py \
  --primary outputs/population_ai_pr_500_20260616/reports/annotation_sheet_completed.csv \
  --external <completed_external_audit_sheet.csv> \
  --manifest outputs/external_audit_slice_20260617/external_audit_manifest.json \
  --out outputs/external_audit_analysis_20260617
```

The analysis emits `external_audit_summary.json/md`,
`external_audit_agreement_by_category.csv`, a LaTeX-ready external-audit table,
and disagreement files. If any audit-code cell is blank or invalid, the report
stays `incomplete` and must not be cited as external agreement.
